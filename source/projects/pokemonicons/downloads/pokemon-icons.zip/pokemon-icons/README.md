# The Artificial's Pokémon icons

We created these as fans of the Pokémon Go game, so will be updating the set as pokémon are added to that world.

All of our icons are licensed [CC-BY](https://creativecommons.org/licenses/by/3.0/). This means they're free to use if you give us credit. Please provide a link to theartificial.com.

Please note that while the artwork is wholly the creation of The Artificial, the represented pokémon are of course the property of The Pokémon Company.
